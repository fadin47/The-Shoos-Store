const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const items = new Schema({
    condition: {type: String, required: [true, 'condition is required']},
    title: {type: String, required: [true, 'title is required']},
    seller: {type: Schema.Types.ObjectId, ref: 'User'},
    price: {type: String, required: [true, 'price is required']},
    details: {type: String, required: [true, 'details is required']},
    totalOffers: {type: Number, required: [true, 'total offers is required']},
    active: {type: String, default: 'true'},
    highestOffer: {type: Number, default: 0},
    image: {type: String, required: [true, 'image is required'],

   
             minLength: [10, 'the content schould have at least 10 characters']}
},
{timestamps: true}
);

module.exports = mongoose.model('shoe', items);