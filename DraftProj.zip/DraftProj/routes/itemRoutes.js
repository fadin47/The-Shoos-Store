const express = require('express');
const controller = require('../controllers/itemsController');
const router = express.Router();
const {fileUpload} = require('../middleware/fileUpload');
const {isLoggedIn, isSeller, isEdited} = require('../middleware/auth');
const {validateId, validateStory, validateResult} = require('../middleware/validator');
const offersRoutes = require('./offers');


router.use('/:id/offers', offersRoutes);

router.get('/', controller.index);

router.get('/new', isLoggedIn, controller.new);

router.post('/', isLoggedIn, validateResult, fileUpload, controller.create);

router.get('/:id', validateId, controller.show);

router.get('/:id/edit', validateId, isLoggedIn, isSeller, isEdited, controller.edit);

router.put('/:id', validateId, isLoggedIn, isSeller, validateResult, controller.update);

router.delete('/:id', validateId, isLoggedIn, isSeller, controller.delete);

router.post('/search', controller.search);


module.exports = router;