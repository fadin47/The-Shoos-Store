const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const {isGuest, isLoggedIn} = require('../middleware/auth');
const {logInLimiter} = require('../middleware/rateLimiters');
const {validateSignUp, validateLogIn, validateResult} = require('../middleware/validator');


router.get('/new', isGuest, userController.new);

router.post('/', isGuest, validateSignUp, validateResult, userController.create);

router.get('/login', isGuest, userController.loginForm);

router.post('/login', logInLimiter, isGuest, validateLogIn, validateResult, userController.login);

router.get('/profile', isLoggedIn, userController.profile);

router.get('/logout', isLoggedIn, userController.logout);


module.exports = router;