const express = require('express');
const offerController = require('../controllers/offerController');
const {isLoggedIn, isSeller, isEdited} = require('../middleware/auth');
const {validateId, validateStory, validateResult} = require('../middleware/validator');
const router = express.Router({mergeParams: true});


router.post('/', offerController.makeOffer);

router.get('/', offerController.viewAllOffers);

router.post('/:offerId/accept', isLoggedIn, isSeller, offerController.acceptOffer);

module.exports = router;
