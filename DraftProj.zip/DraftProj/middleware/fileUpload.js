const multer = require('multer');
const path = require('path');

// Define storage settings for multer
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    // Specify the destination folder for storing images
    cb(null, './public/images');
  },
  filename: function (req, file, cb) {
    // Generate a unique filename for the uploaded image
    const uniqueFilename = Date.now() + '-' + Math.round(Math.random() * 1E9) + path.extname(file.originalname);
    cb(null, uniqueFilename);
  }
});

// Define file filter to accept only specific image file types
const fileFilter = (req, file, cb) => {
  const allowedMimeTypes = ['image/jpeg', 'image/png', 'image/gif'];
  if (allowedMimeTypes.includes(file.mimetype)) {
    cb(null, true); // Accept the file
  } else {
    cb(new Error('Invalid file type. Only jpg, jpeg, png and gif image files are allowed.'), false); // Reject the file
  }
};

// Configure multer with storage and file filter settings
const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 10 * 1024 * 1024 } // Limit file size to 10MB
}).single('image'); // Accept only single image uploads

// Middleware function to handle file upload
exports.fileUpload = (req, res, next) => {
  upload(req, res, function (err) {
    if (err) {
      // Handle multer errors
      if (err instanceof multer.MulterError) {
        return res.status(400).send('An unexpected error occurred during file upload.');
      } else {
        return res.status(500).send('An unknown error occurred during file upload.');
      }
    }
    next(); // Proceed to the next middleware
  });
};