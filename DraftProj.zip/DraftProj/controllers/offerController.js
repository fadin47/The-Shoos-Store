const User = require('../models/user');
const Shoe = require('../models/shoe'); 
const Offer = require('../models/offer');

exports.makeOffer = async (req, res) => {
  let id = req.params.id;
  try {
    console.log("Received item ID in makeOffer:", req.params.id);

    // Check if user is logged in
    if (!req.session.user) {
      return res.redirect('/user/login'); // Redirect to login page
    }

    // Retrieve shoe by ID
    const shoe = await Shoe.findById(req.params.id); 
    if (!shoe) {
      return res.status(404).json({ error: 'Shoe not found' });
    }

    // Check if shoe is active
    if (shoe.active != 'true') {
      return res.status(400).json({ error: 'Shoe is not active' }); 
    }

    // Check if user is seller of the shoe
    if (shoe.seller.toString() === req.session.user) {
      return res.status(401).json({ error: 'You cannot make an offer on your own shoe' }); 
    }

    // Create new offer
    const offer = new Offer({
      user: req.session.user,
      item: shoe.id,
      amount: req.body.amount,
      status: 'pending'
    });

    // Save offer
    await offer.save();

    // Update shoe document
    shoe.totalOffers++;
    if (req.body.amount > shoe.highestOffer) {
      shoe.highestOffer = req.body.amount;
    }
    await shoe.save();

    res.redirect(`/items/${req.params.id}`);
  } catch (error) {
    console.error(error.message);
    res.status(500).json({ error: 'Server Error' });
  }
};

exports.viewAllOffers = async (req, res) => {
  let id = req.params.id;
  try {
    // Retrieve shoe by ID
    const shoe = await Shoe.findById(req.params.id); 
   if (!shoe) {
      return res.status(404).json({ error: 'Shoe not found' });
    }
    
    // Check if user is the owner of the shoe
    if (shoe.seller.toString() !== req.session.user) {
      return res.status(403).json({ error: 'You are not authorized to view offers for this shoe' }); 
    }
    
    // Retrieve all offers for the shoe
    let [offers, items ] = await Promise.all([
      Offer.find({ item: shoe.id }).populate('user', 'firstName lastName').lean(),
      Shoe.findById(id)
    ])
    res.render('./shoe/offers' , {offers, items});
  } catch (error) {
    next(error);
    console.error(error.message);
    res.status(500).json({ error: 'Server Error' });
  }
};

exports.acceptOffer = async (req, res) => {
  try {
    const shoeId = req.params.id;
    const offerId = req.params.offerId;

    // Retrieve shoe by ID
    const shoe = await Shoe.findById(shoeId);
    if (!shoe) {
      return res.status(404).json({ error: 'Shoe not found' });
    }

    // Check if user is the owner of the shoe
    if (shoe.seller.toString() !== req.session.user) {
      return res.status(403).json({ error: 'You are not authorized to accept offers for this shoe' });
    }

    // Retrieve offer by ID
    const offer = await Offer.findById(offerId);
    if (!offer) {
      return res.status(404).json({ error: 'Offer not found' });
    }

    // Set active field of the shoe to false
    shoe.active = false;
    await shoe.save();

    // Update status of the accepted offer to 'accepted'
    offer.status = 'accepted';
    await offer.save();

    // Update status of other pending offers on the same shoe to 'rejected'
    await Offer.updateMany({ item: shoeId, status: 'pending', _id: { $ne: offerId } }, { status: 'rejected' });

    // Redirect the user to the offers view
    res.redirect(`/items/${shoeId}/offers`);
  } catch (error) {
    console.error(error.message);
    res.status(500).json({ error: 'Server Error' });
  }
};