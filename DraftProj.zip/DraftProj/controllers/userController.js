const User = require('../models/user');
const model = require('../models/shoe');
const viewOffer = require('../models/offer');

exports.new = (req, res) => {
    res.render('user/new');
};

exports.create = (req, res, next) => {
    // Create a new user
    // Logic for user creation
    
    let user = new User(req.body);
    user.save()
        .then(user => res.redirect('/user/login'))
        .catch(err => {
            if (err.name === 'ValidationError') {
                req.flash('error', err.message);
                return res.redirect('/user/new');
            }
            if (err.code === 11000) {
                req.flash('error', 'Email address already in use');
                return res.redirect('/user/new');
            }
            next(err);
        });
};

exports.loginForm = (req, res) => {
    // Render login form
    res.render('user/login');
};

exports.login = (req, res, next) => {
    // Handle user login
    let email = req.body.email;
    if(email)
        email = email.toLowerCase();
    let password = req.body.password;
    User.findOne({ email: email })
        .then(user => {
            if (user) {
                user.comparePassword(password)
                    .then(result => {
                        if (result) {
                            req.session.user = user._id; // Store user's id in session
                            req.flash('success', 'You have successfully logged in');
                            res.redirect('/user/profile');
                        } else {
                            console.log('wrong password');
                            req.flash('error', 'Wrong password');
                            res.redirect('/user/login');
                        }
                    });
            } else {
                console.log('wrong email address');
                req.flash('error', 'Wrong email address');
                res.redirect('/user/login');
            }
        })
        .catch(err => next(err));
};

exports.profile = async (req, res, next)=>{
    let id = req.session.user;
    Promise.all([viewOffer.find({user: id}), model.find({seller: id})])
    .then(results=>{
        const [offers, items] = results;
        res.render('./user/profile', {offers, items});
    })
    .catch(err=>next(err));
};

exports.logout = (req, res, next) => {
    // Handle user logout
    // Logic for user logout
    req.session.destroy(err => {
        if (err)
            return next(err);
        else
            res.redirect('/');
    });
};