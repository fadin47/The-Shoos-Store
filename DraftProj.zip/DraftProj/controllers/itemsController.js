const model = require('../models/shoe');

exports.index = (req, res, next) => {
    model.find().sort({ price: 1 }) // Sort by price in ascending order (cheapest to most expensive)
        .then(items => res.render('./shoe/index', { items }))
        .catch(err => next(err));
};


exports.new = (req, res)=>{
    res.render('./shoe/new');
};


exports.create = (req, res, next)=>{
    //res.send('Created a new shoe');
    let shoe = new model(req.body); //create a new shoe listing
    shoe.seller = req.session.user;
    shoe.image = '/images/' + req.file.filename;
    shoe.save()
    .then(shoe=>res.redirect('/items'))
    .catch(err=>{
        if(err.name === 'ValidationError'){
            err.status = 400;
        }
        next(err);
    });
};


exports.show = (req, res, next) => {
    let id = req.params.id;
    model.findById(id)
        .populate('seller', 'firstName lastName') // Populate the seller field with first name and last name
        .then(shoe => {
            if (shoe) {
                return res.render('./shoe/show', { shoe });
            } else {
                let err = new Error('Cannot find a shoe with id ' + id);
                err.status = 404;
                next(err);
            }
        })
        .catch(err => next(err));
};


exports.edit = (req, res, next)=>{
    let id = req.params.id;
    model.findById(id).populate('seller', 'firstName lastName')
    .then(shoe=>{
            return res.render('./shoe/edit', {shoe});
    })
    .catch(err=>next(err));
};


exports.update = (req, res, next)=>{
    let shoe = req.body;
    let id = req.params.id;

   

    model.findByIdAndUpdate(id, shoe, {useFindAndModify: false, runValidators: true})
    .then(shoe=>{
            res.redirect('/items/'+id);   
    })
    .catch(err=>{
        if(err.name === 'ValidationError')
        err.status = 400;
        next(err);
    });
};


exports.delete = (req, res, next)=>{
    let id = req.params.id;

    model.findByIdAndDelete(id, {useFindAndModify: false})
    .then(shoe=>{
        if(shoe)
            res.redirect('/items');
    })
    .catch(err=>next(err));
};


exports.search = async (req, res, next) => {
    try {
        const searchTerm = req.body.search.toLowerCase();
        const items = await model.find();

        const matchedItems = items.filter(item =>
            item.title.toLowerCase().includes(searchTerm) ||
            item.seller.toLowerCase().includes(searchTerm) ||
            item.details.toLowerCase().includes(searchTerm)
        );
        res.render('./shoe/index', { items: matchedItems });
    } catch (error) {
        next(error); 
    }
};